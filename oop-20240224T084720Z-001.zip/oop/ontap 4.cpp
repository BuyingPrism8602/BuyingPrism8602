#include<iostream>
#include<cstring>
using namespace std;
class Truong {
	private:
		char matruong[10], malop[10];
		int solop, sosv;
	public:
		Truong(char *matruong = " ", char *malop = " ", int solop = 0, int sosv = 0) {
			strcpy(this->matruong, matruong);
			strcpy(this->malop, malop);
			this->solop = solop;
			this->sosv = sosv;
		}
		~Truong() {
		}
		friend istream& operator>>(istream &is, Truong &t) {
			fflush(stdin);
			cout << "Nhap ma truong: "; is.getline(t.matruong, 10);
			cout << "Nhap ma lop: "; is.getline(t.malop, 10);
			cout << "Nhap so lop: "; is >> t.solop;
			cout << "Nhap so sinh vien: "; is >> t.sosv;
		}
		friend ostream& operator<<(ostream &os, Truong t) {
			os << "Ma truong: " << t.matruong << endl;
			os << "Ma lop: " << t.malop << endl;
			os << "So lop: " << t.solop << endl;
			os << "So sinh vien: " << t.sosv << endl;
		}
		char *getmatruong() {
			return matruong;
		}
		int getsosv() {
			return sosv;
		}
};
class TruongDaiHoc: public Truong {
	private:
		char ten[40];
		int socn;
	public:
		TruongDaiHoc(char *matruong = " ", char *malop = " ", int solop = 0, int sosv = 0, char *ten = " ", int socn = 0): Truong(matruong, malop, socn) {
			strcpy(this->ten, ten);
			this-> socn = socn; 
		}
		~TruongDaiHoc() {
		}
		friend istream &operator>>(istream &is, TruongDaiHoc &tdh) {
			is >> (Truong &)tdh;
			fflush(stdin);
			cout << "Nhap ten truong: "; is.getline(tdh.ten, 40);
			cout << "Nhap so chuyen nganh: "; is >> tdh.socn;
		}
		friend ostream &operator<<(ostream &os, TruongDaiHoc tdh) {
			os << (Truong &)tdh;
			os << "Ten truong: " << tdh.ten << endl;
			os << "So chuyen nganh: " << tdh.socn << endl;
		}
		friend bool operator < (TruongDaiHoc t, int h) {
			if(t.socn < h)
			return true;
			else return false;
		}
};
int main() {
	Truong t[100];
	int m;
	cout << "Nhap so truong: "; cin >> m;
	for(int i = 0; i < m; i++) {
		cout << "-STT: " << i + 1 << endl; 
		cin >> t[i];
	}
	cout << "---DANH SACH TRUONG---" << endl;
	for(int i = 0; i < m; i++) {
		cout << t[i];
	}
	TruongDaiHoc u[100];
	int n;
	cout << "Nhap so truong dai hoc: "; cin >> n;
	for(int i = 0; i < n; i++) {
		cout << "-Stt: " << i + 1 << endl;
		cin >> u[i];
	}
	cout << "---DS TRUONG DAI HOC ---" << endl;
	for(int i = 0; i < n; i++) {
		cout << "-Stt: " << i + 1 << endl;
		cout << u[i];
	}
	cout << "---DS TRUONG DAI HOC MA: UNETI---" << endl;
	for(int i = 0; i < n; i++) {
		if(strcmp(u[i].getmatruong(), "UNETI") == 0)
			cout << u[i];
	}
	cout << "---DS TRUONG DAI HOC TREN 1000 SV---" << endl;
	for(int i = 0; i < n; i++) {
		if(u[i].getsosv() > 1000)
		cout << u[i];
	}
	char s[10];
	cout << "**Nhap ten truong dai hoc can tim: "; cin >> s;
	for(int i = 0; i < n; i++) {
		if(strcmp(u[i].getmatruong(), s) == 0)
		cout << u[i];
	}
	cout << "**Ds tdh sau khi sap xep:" << endl;
	for(int i = 0; i < n; i++) {
		for(int j = n - 1; j > i; j--) {
			if(u[j].getsosv() > u[j - 1].getsosv())
			swap(u[j],u[j - 1]);
		}
		cout << u[i];
	}
	int k;
	cout << "Nhap vi tri thu (k + 1) can xoa: "; cin >> k;
	for(int i = k; i < n; i++) {
		u[i] = u[i + 1];
	}
	n--;
	cout << "---DS TRUONG DAI HOC SAU KHI XOA 1 TRUONG---" << endl;
	for(int i = 0; i < n; i++) {
		cout << "-Stt: " << i + 1 << endl;
		cout << u[i];
	}
	TruongDaiHoc x;
	int q;
	cout << "Nhap vi tri thu (k + 1) can them: "; cin >> q >> x;
	for(int i = n - 1; i >= q + 1; i--) {
		u[i] = u[i - 1];
	}
	u[q] = x;
	n++;
	cout << "---DS TRUONG DAI HOC SAU KHI THEM 1 TRUONG---" << endl;
	for(int i = 0; i < n; i++) {
		cout << "-Stt: " << i + 1 << endl;
		cout << u[i];
	}
	cout << "---DS TRUONG DAI HOC IT HON 10 CHUYEN NGANH---" << endl;
	for(int i = 0; i < n; i++) {
		if(u[i] < 10)
		cout << u[i];
	}
	return 0;
}
