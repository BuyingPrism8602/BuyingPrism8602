#include<iostream>
#include<cstring>
#include<conio.h>
using namespace std;
class GV {
	private:
		char ht[30], bc[15], cn[20];
		int tuoi;
		float bl;
	public:
		void nhap() {
			cout << "Nhap ho ten giao vien: "; cin >> ht;
			cout << "Nhap tuoi: "; cin >> tuoi;
			cout << "Nhap bang cap: "; cin >> bc;
			cout << "Nhap chuyen nganh: "; cin >> cn;
			cout << "Nhap bac luong: "; cin >> bl;
		}
		float tinhluong() {
			return bl * 610;
		}
		void in() {
			cout << "Ho ten: " << ht << endl;
			cout << "Tuoi: " << tuoi << endl;
			cout << "Bang cap: " << bc << endl;
			cout << "Chuyen nganh: " << cn << endl;
			cout << "Luong: " << tinhluong() << endl;
		}
		char* getcn() {
			return cn;
		}
};
int main() {
	int n;
	cout << "Nhap so giao vien:" ; cin >> n;
	GV g[100];
	for(int i = 0; i < n; i++) {
		cout << "So thu tu: " << i + 1 << endl;
		g[i].nhap();
		
	}
	cout << "***DANH SACH GIAO VIEN***" << endl;
	for(int i = 0; i < n; i++) {
		if (g[i].tinhluong() < 2000) {
		g[i].in();
	}
	}
	cout << "DANH SACH SAU KHI SAP XEP LA:" << endl;
	for(int i = 0; i < n; i++) {
		for(int j = n - 1; j > i; j--) {
			if(strcmp(g[j].getcn() ,g[j-1].getcn()) < 0)
			swap(g[j], g[j-1]);
		}
		cout << "---So thu tu: " << i + 1 << endl;
		g[i].in();
	}
	return 0;
}
