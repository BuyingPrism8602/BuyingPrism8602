#include<iostream>
using namespace std;
class HCN {
	private:
		float d, r;
	public:
		void nhap() {
			cout << "nhap chieu dai: "; cin >> d;
			cout << "nhap chieu rong: "; cin >> r;
		}
		void inthongtin() {
			cout << "(" << d << " , " << r << ")";
		}
		float tinhchuvi() {
			return 2*(d + r);
		}
		float tinhdientich(){
			return d * r;
		}
};
int main() {
	HCN h1;
	h1.nhap();
	h1.inthongtin();
	cout << endl;
	cout << h1.tinhchuvi() << endl;
	cout << h1.tinhdientich() << endl;
}
