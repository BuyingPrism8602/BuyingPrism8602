#include<iostream>
using namespace std;
class X {
	protected:
		char ms[10];
		long dg;
		int sl;
		char nxb[40];
	public:
		virtual void nhap() {
			cout << "Nhap ma sach: "; cin.getline(ms, 10);
			cout << "Nhap don gia: "; cin >> dg;
			cout << "Nhap so luong: "; cin >> sl;
			fflush(stdin);
			cout << "Nhap nha xuat ban: "; cin.getline(nxb, 40);
		}
		virtual long thanhtien() = 0;
		virtual void in() {
			cout << "Ma sach: " << ms << endl;
			cout << "Don gia: " << dg << endl;
			cout << "So luong: " << sl << endl;
			cout << "Nha xuat ban: " << nxb << endl;
		}
};
class SGK : public X{
	bool tt;
	public:
		void nhap() {
			X::nhap();
			cout << "Nhap tinh trang(1: moi, 0: cu): "; cin >> tt;
		}
		long thanhtien() {
			if(tt==true) return sl * dg;
			else return sl * dg * 0.5;
		}
		void in() {
			X::in();
			cout << "Tinh trang: " << tt << endl;
			cout << "Thanh tien: "<< thanhtien() << endl;
		}
		
};
class STK : public X{
	long thue;
	public:
		void nhap() {
			X::nhap();
			cout << "Nhap thue: "; cin >> thue;
		}
		long thanhtien() {
			return sl * dg + thue;
		}
		void in() {
			X::in();
			cout << "Thue: " << thue << endl;
			cout << "Thanh tien: " << thanhtien() << endl;
		}
};
int main() {
	X *s[100];
	int k = 0, chon, i;
		while(1) {
		cout << "Moi nhap doi tuong: 1.SGK, 2.STK, 3.thoat: " << endl;
		cin >> chon; cin.get();
		if (chon==1) s[k]=new SGK();
      	if (chon==2) s[k]=new STK();
      	if (chon==3) break;
      	s[k]->nhap();   //????
	  	k++;
	}
   	for (i=0; i<k; i++)
        s[i]->in();  
}
