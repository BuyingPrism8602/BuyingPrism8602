#include<iostream>
#include<cstring>
using namespace std;
class DUOCPHAM {
	private:
		char masp[10], tensp[30];
		long giact;
	public:
		DUOCPHAM(char *masp = " ", char *tensp = " ", long giact = 0) {
			strcpy(this->masp, masp);
			strcpy(this->tensp, tensp);
			this->giact = giact;
		}
		~DUOCPHAM(){
		}
		void input() {
			fflush(stdin);
			cout << "Nhap ma san pham: "; cin.getline(masp, 10);
			cout << "Nhap ten san pham: "; cin.getline(tensp, 30);
			cout << "Nhap gia chua thue: "; cin >> giact;
		}
		void output() {
			cout << "-Ma san pham: " << masp << endl;
			cout << "Ten san pham: " << tensp << endl;
			cout << "Gia: " << giact << endl;
		}
		long getgiact() {
			return giact;
		}
		char *getmasp() {
			return masp;
		}
};
class THUOC: public DUOCPHAM {
	private:
		char loai[20], tpthuoc[40];
		int dd, mm, yyyy;
	public:
		THUOC(char *masp = " ", char *tensp = " ", long giact = 0, char *loai = " ", int dd = 0, int mm = 0, int yyyy = 0, char *tpthuoc = " "): DUOCPHAM(masp, tensp, giact) {
			strcpy(this->loai, loai);
			this->dd = dd;
			this->mm = mm;
			this->yyyy = yyyy;
			strcpy(this->tpthuoc, tpthuoc);
		}
		friend istream& operator>>(istream &is, THUOC &th) {
			th.input();
			fflush(stdin);
			cout << "Nhap loai thuoc: "; is.getline(th.loai, 20);
			cout << "Nhap HSD: "; cin >> th.dd >> th.mm >> th.yyyy;
			fflush(stdin);
			cout << "Nhap thanh phan thuoc: "; is.getline(th.tpthuoc, 40);
		}	
		friend ostream& operator<<(ostream &os, THUOC th) {
			th.output();
			os << "Loai thuoc: " << th.loai << endl;
			os << "HSD: " << th.dd << "/" << th.mm << "/" << th.yyyy << endl;
			os << "Nhap thanh phan thuoc: " << th.tpthuoc << endl;
			os << "Gia: " << th.giast() << endl;
		}
		long giast() {
			return getgiact() * 1.1;
		}
		friend bool operator > (THUOC t1, THUOC t2) {
			if(strcmp(t1.getmasp(),t2.getmasp()) > 0)
			return true;
		} 
};
int main() {
	DUOCPHAM d[100];
	int m;
	cout << "Nhap so duoc pham: "; cin >> m;
	for(int i = 0; i < m; i++) {
		cout << "-Stt: " << i + 1 << endl;
		d[i].input();
	}
	cout << "----DANH SACH DUOC PHAM----" << endl;
	for(int i = 0; i < m; i++) {
		d[i].output();
	}
	THUOC t[100];
	int n;
	cout << "Nhap so duoc pham: "; cin >> n;
	for(int i = 0; i < n; i++) {
		cout << "-STT: " << i + 1 << endl;
		cin >> t[i];
	}
	cout << "---DANH SACH THUOC---" << endl;
	for(int i = 0; i < n; i++) {
		for(int j = n - 1; j > i; j--) {
			if(t[j] > t[j - 1]) {
				THUOC a = t[j];
				t[j] = t[j - 1];
				t[j - 1] = a;
			}
		}
		cout << t[i];
	}
	int k;
	cout << "Nhap vi tri can xoa: "; cin >> k;
	for(int i = k; i < n; i++) {
		t[i] = t[i + 1];
	}
	n--;
	cout << "DS THUOC SAU KHI XOA LA:" << endl;
	for(int i = 0; i < n; i++) {
		cout << t[i];
	}
	return 0;
}
