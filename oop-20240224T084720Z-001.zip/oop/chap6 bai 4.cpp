#include<iostream>
using namespace std;
template <class M> class Matrix {
	private:
		int n;
		M a[100];
	public:

		Matrix(M a[0] = 0, int n = 0) {
			this->n = n;
			for(int i = 0; i < n; i++) {
				this->a[i] = a[i];
			}
		}
		void nhap() {
			cout << "Nhap so phan tu: "; cin >> n;
			cout << "Nhap cac phan tu: "; 
			for(int i = 0; i < n; i++) {
				cin >> a[i];
			}
		}
		void in() {
			for(int i = 0; i < n; i++) {
				cout << a[i] <<" ";
			}
		}
		Matrix operator+(Matrix m) {
			int n;
			Matrix m1;
			for(int i = 0; i < n; i++) {
				m1.a[i] = this->a[i] + m.a[i];
			}
			return m1;
		}	
};
int main() {
	Matrix <int> a ,b ,c;
	cout << "Ma tran 1: "; a.nhap();
	a.in();
	cout << "Ma tran 2: "; b.nhap();
	b.in();
	c = a + b;
	c.in();
	return 0;
}

