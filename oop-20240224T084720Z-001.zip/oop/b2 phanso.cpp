#include<iostream>
using namespace std;
class PS {
	private:
		int t, m;
	public:
		PS(int t = 1, int m = 1) {
			this->t = t;
			this->m = m;
		}
		~PS() {
		}
		void in() {
			cout << t << " / " << m << endl;
		}
		void cong(PS p) {
			t = t * p.m + m * p.t;
			m = m * p.m;
		}
		void tru(PS p) {
			t = t * p.m - m * p.t;
			m = m * p.m;
		}
		void nhan(PS p) {
			t = t * p.t;
			m = m * p.m;
		}
		void chia(PS p) {
			t = t * p.m;
			m = m * p.t;
		}
};
int main() {
	int t1, m1, t2, m2;
	cout << "Nhap tu so, mau so cua phan so thu nhat: "; cin >> t1 >> m1;
	cout << "Nhap tu so, mau so cua phan so thu hai: "; cin >> t2 >> m2;
	PS p1(t1, m1), p2(t2, m2), p3;
	p3 = p1; p3.cong(p2);
	cout << "Tong hai phan so la: "; p3.in();
	p3 = p1; p3.tru(p2);
	cout << "Hieu hai phan so la: "; p3.in();
	p3 = p1; p3.nhan(p2);
	cout << "Tich hai phan so la: "; p3.in();
	p3 = p1; p3.chia(p2);
	cout << "Thuong hai phan so la: "; p3.in();
}
