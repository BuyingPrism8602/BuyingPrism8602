#include<iostream>
using namespace std;
class PS {
	private:
		int t, m;
	public:
		PS(int t = 1, int m = 1) {
			this->t = t;
			this->m = m;
		}		
		void nhap() {
			cout << "Nhap tu so, mau so: "; cin >> t >> m;
		}
		void in() {
			cout << t << " / " << m << endl;
		}
		PS operator+ (PS p) {
			PS s;
			s.t = this->t * p.m + this->m * p.t;
			s.m = this->m * p.m;
			return s;
		}
		int UCLN(int a, int b) {
			if(b == 0) return a;
			else return UCLN(b, a%b);
		}
		void rutgon() {
			int a = UCLN(t, m);
			t = t/a;
			m = m/a;
		}
		int gett() {
			return t;
		}
		int getm() {
			return m;
		}
		
};
template<class T>
T sum(int n) {
	T S =0, a[100];
	for(int i = 0; i < n; i++) {
		S += a[i];
	}
}
int main() {
	PS p[100];
	int n;
	cout << "Nhap so phan so: "; cin >> n;
	for(int i = 0; i < n; i++) {
		cout << "Phan so thu nhat: "; p[i].nhap();
	}
	PS S = 0;
	for(int i = 0; i < n; i++) {
		S = S + p[i];
	}
	S.rutgon();
	S.in();
}
