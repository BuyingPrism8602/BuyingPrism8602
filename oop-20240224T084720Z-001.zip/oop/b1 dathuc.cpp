#include<iostream>
using namespace std;
class DaThuc3 {
	private:
		int a, b, c, d;
	public:
		DaThuc3(int a = 0, int b = 0, int c = 0, int d = 0) {
			this->a = a;
			this->b = b;
			this->c = c;
			this->d = d;
		};
		~DaThuc3() {
		}
		void indathuc() {
			cout << a <<"x^3 + " << b << "x^2 + " << c << "x + "<< d << endl;
		}
};
int main() {
	int a1, b1, c1, d1, a2, b2, c2, d2;
	cout << "nhap cac he so cua da thuc 1: "; cin >> a1 >> b1 >> c1 >> d1;
	cout << "nhap cac he so cua da thuc 2: "; cin >> a2 >> b2 >> c2 >> d2;
	cout << "tong hai da thuc la: ";
	DaThuc3 dt3(a1 + a2, b1 + b2, c1 + c2, d1 + d2);
	dt3.indathuc();
	return 0;
}
