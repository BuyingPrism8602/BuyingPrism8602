#include<iostream>
#include<cstring>
using namespace std;
class KH {
	private:
		char ht[30], cmt[10], k[50];
		int day, month, year;
	public:
		void nhap() {
			cout << "nhap ho ten: "; cin >> ht;
			cout << "nhap ngay sinh: "; cin >> day;
			cout << "nhap thang sinh: "; cin >> month;
			cout << "nhap nam sinh: "; cin >> year;
			cout << "nhap so cmt: "; cin >> cmt;
			cout << "nhap ho khau: "; cin >> k;
		}
		
		void in() {
			cout << "Ho ten: " << ht <<endl;
			cout << "Ngay sinh: " <<day <<endl;
			cout << "Thang sinh:" << month <<endl;
			cout << "Nam sinh: " << year <<endl;
			cout << "So cmt: " << cmt <<endl;
			cout << "Ho khau thuong tru: " << k <<endl;
		}
		int getmonth() {
			return month;
		}
		char* getht() {
			return ht;
		}
		
};
int main() {
	KH kh[50];
	int n;
	cout << "nhap so khach hang: "; cin >> n;
	for(int i = 0; i < n; i++) {
		cout << "---Khach hang so " << i + 1 << ": " << endl;
		kh[i].nhap();
	
	}
	cout << "****DANH SACH KHACH HANG SINH THANG 12:****" << endl;
	for(int i = 0; i < n; i++) {
		if(kh[i].getmonth() == 12) {
		cout << "---Khach hang so " << i + 1 << ": " << endl;
		kh[i].in();
	}
}
	cout << "----DANH SACH KHACH HANG SAU KHI SAP XEP----" <<endl;
	for(int i = 0; i < n; i++) {
		for(int j = n - 1; j > i; j--) {
			if(strcmp(kh[j].getht(),kh[j-1].getht()) < 0) {
			swap(kh[j], kh[j-1]);
			}
		}
		cout << "---Khach hang so " << i + 1 << ": " << endl;
		kh[i].in();
	}
	
	return 0;
}
