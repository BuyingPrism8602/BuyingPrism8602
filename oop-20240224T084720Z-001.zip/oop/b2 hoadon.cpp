#include<iostream>
#include<string.h>
#include<iomanip>
using namespace std;
struct Ngaylap {
	int dd, mm, yyyy;	//ngay thang nam
};
class HD {
	private:
		char mavt[10];	//ma vat tu
		char tenvt[30];	//ten vat tu
		char lp[15];	// loai phieu
		Ngaylap d;
		int kl;			//khoi luong
		long dg, tt;	//don gia, thanh tien
	public:
		void nhap();
		friend long tien(HD h);
		void in();	
};
void HD::nhap() {
	cout << "Nhap ma vat tu: " ; cin >> mavt;
	cout << "Nhap ten vat tu: "; cin >> tenvt;
	cout << "Nhap loai phieu: "; cin >> lp;
	cout << "Nhap ngay lap: "; cin >> d.dd >> d.mm >> d.yyyy;
	cout << "Nhap khoi luong: ";cin >> kl;
	cout << "Nhap don gia: "; cin >> dg;
}
long tien(HD h) {
	h.tt = h.kl * h.dg;
	return h.tt;
}
void HD::in() {
	cout << setw(10) << mavt;
	cout << setw(30) << tenvt;
	cout << setw(15) << lp;
	cout << setw(4) << d.dd << "/" << setw(2) << d.mm << "/" << setw(2) <<  d.yyyy;
	cout << setw(15) << kl;
	cout << setw(10) << dg;
}
int main() {
	int n;
	cout << "Nhap so hoa don: "; cin >> n;
	HD hd[100];
	for(int i = 0; i < n; i++) {
		cout << "-Hoa don so " << i + 1 << endl;
		hd[i].nhap();
	}
	cout << '\t' <<"***---DANH SACH HOA DON---***"<< endl;
	cout << setw(10) << "Ma vat tu";
	cout << setw(30) << "Ten vat tu";
	cout << setw(15) << "Loai phieu";
	cout << setw(12) << "Ngay lap";
	cout << setw(15) << "Khoi luong";
	cout << setw(10) << "Don gia";
	cout << setw(15) << "Thanh tien" << endl;
	for(int i = 0; i < n; i++) { //sap xep
		for(int j = n - 1; j > i; j--) {
			if(tien(hd[j]) > tien(hd[j-1])) {
				HD t = hd[j];
				hd[j] = hd[j-1];
				hd[j-1] = t;
			}
		}
	}
	for(int i = 0; i < n; i++) {
		hd[i].in();
		cout << setw(15) << tien(hd[i]) << endl;
	}
	return 0;
}


