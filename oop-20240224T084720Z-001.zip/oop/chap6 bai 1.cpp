#include<iostream>
#include<cstring>
using namespace std;
template<class M>
M maxarray(M a[], int n) {
	M max = a[0];
	for(int i = 0; i < n; i++){
		if(a[i] > max) max = a[i];
	}
	cout << "Max = " ;
	return max;
}
char maxarray(char s[], int n) {
	char max = s[0];
	for(int i = 0; i < strlen(s); i++) {
		if(s[i] > max) max = s[i];
	}
	return max;
}
int main() {
	int n;
	char a[100];
	cout << "Nhap so phan tu mang: "; cin >> n;
	cout << "Nhap phan tu: ";
	for(int i = 0; i < n; i++)  {
		cin >> a[i];
	}
	cout << maxarray(a, n);
	return 0;
}
