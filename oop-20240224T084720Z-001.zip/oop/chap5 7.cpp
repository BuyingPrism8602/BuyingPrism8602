#include<iostream>
using namespace std;
class Benhnhan{
	protected:
		char mahs[10];
		char hoten[30];
		int ngay, thang, nam;
	public:
		virtual void nhap() {
			cout << "Nhap ma ho so:  "; cin.getline(mahs, 10);
			cout << "Nhap ho ten benh nhan: ";cin.getline(hoten, 30);
			cout << "Nhap ngay sinh: "; cin >> ngay >> thang >> nam;	
		}
		virtual void in() {
			cout << "Ma ho so: " << mahs << endl;
			cout << "Ho ten: " << hoten << endl;
			cout << "Ngay sinh: " << ngay << " - " << thang << " - " << nam <<endl;
		}
		int getngay() {
			return ngay;
		}
};
class BNnoitru: public Benhnhan{
		int ngaynv, thangnv, namnv;
		int ngayrv, thangrv, namrv;
		char chandoan[40];
		char tenkhoa[40];
		int sogiuong;
	public:
		void nhap() {
			Benhnhan::nhap();
			cout << "Nhap ngay nhap vien: "; cin >> ngaynv >> thangnv >> namnv;
			cout << "Nhap ngay ra vien: "; cin >> ngayrv >> thangrv >> namrv;
			fflush(stdin);
			cout << "Nhap chan doan benh: "; cin.getline(chandoan, 40);
			cout << "Nhap ten khoa: "; cin.getline(tenkhoa, 40);
			cout << "Nhap so giuong: "; cin >> sogiuong;
		}
		void in() {
			Benhnhan::in();
			cout << "Ngay nhap vien: " << ngaynv << " - " << thangnv << " - " << namnv <<endl;
			cout << "Ngay ra vien: " << ngayrv << " - " << thangrv << " - " << namrv <<endl;
			cout << "Chan doan benh: " << chandoan << endl;
			cout << "Ten khoa: " << tenkhoa << endl;
			cout << "So giuong: " << sogiuong << endl;
		}
};
class BNngoaitru: public Benhnhan{
		char chandoan[40];
		int ngaycv, thangcv, namcv;
		char noichuyen[40];
	public:
		void nhap() {
			Benhnhan::nhap();
			fflush(stdin);
			cout << "Nhap chan doan benh: "; cin.getline(chandoan, 40);
			cout << "Nhap ngay chuyen vien: "; cin >> ngaycv >> thangcv >> namcv;
			fflush(stdin);
			cout << "Nhap noi chuyen: "; cin.getline(noichuyen, 40);
		}
		void in() {
			Benhnhan::in();
			cout << "Chan doan benh: " << chandoan << endl;
			cout << "Ngay chuyen vien: " << ngaycv << " - " << thangcv << " - " << namcv << endl;
			cout << "Noi chuyen: " << noichuyen << endl;
		}
};
int main() {
	Benhnhan *b[100];
	int k = 0, chon, i;
	while(1) {
		cout << "Moi nhap doi tuong: 1.noi tru, 2.ngoai tru, 3.thoat: " << endl;
		cin >> chon; cin.get();
		if (chon==1) b[k]=new BNnoitru();
      	if (chon==2) b[k]=new BNngoaitru();
      	if (chon==3) break;
      	b[k]->nhap();   //????
	  	k++;
	}
	int X;
	cout << "Nhap ngay sinh X: "; cin >> X;
   	for (i=0; i<k; i++)
   		if(b[i]->getngay() > X)
        b[i]->in();  
}
