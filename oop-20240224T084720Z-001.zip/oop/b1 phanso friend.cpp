#include<iostream>
using namespace std;
class PS {
	private:
		int t, m;
	public:
		PS(int t = 1, int m = 1) {
			this->t = t;
			this->m = m;
		}
		friend PS operator+(PS p1, PS p2);
		friend PS operator-(PS p1, PS p2);
		friend PS operator*(PS p1, PS p2);
		friend PS operator/(PS p1, PS p2);
		friend istream& operator>>(istream &is, PS &a);
		friend ostream& operator<<(ostream &os, PS a);		
		~PS() {
		}
};

PS operator+(PS p1, PS p2) {
	PS r;
	r.t = p1.t * p2.m + p1.m * p2.t;
	r.m = p1.m * p2.m;
	return r;
}
PS operator-(PS p1, PS p2) {
	PS r;
	r.t = p1.t * p2.m - p1.m * p2.t;
	r.m = p1.m * p2.m;
	return r;
}
PS operator*(PS p1, PS p2) {
	PS r;
	r.t = p1.t * p2.t;
	r.m = p1.m * p2.m;
	return r;
}
PS operator/(PS p1, PS p2) {
	PS r;
	r.t = p1.t * p2.m;
	r.m = p1.m * p2.t;
	return r;
}
istream& operator>>(istream &is, PS &a) {
	cout << "Nhap tu so: "; is >> a.t;
	cout << "Nhap mau so: "; is >> a.m;
}
ostream& operator<<(ostream &os, PS a) {
	cout << a.t << " / " << a.m << endl;
}
int main() {
	PS p1, p2, p3;
	cout << "Nhap phan so 1: " << endl;
	cin >> p1;
	cout << "Nhap phan so 2: " << endl;
	cin >> p2;
	cout << "Tong hai phan so la: ";
	p3 = p1 + p2; 
	cout << p3;
	cout << "Hieu hai phan so la: ";
	p3 = p1 - p2; 
	cout << p3;
	cout << "Tich hai phan so la: "; 
	p3 = p1 * p2; 
	cout << p3;
	cout << "Thuong hai phan so la: "; 
	p3 = p1 / p2; 
	cout << p3;
}
