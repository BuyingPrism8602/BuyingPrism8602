#include<iostream>
#include<string.h>
using namespace std;
struct NS {
	int dd, mm, yyyy;
};
class KH {
	private:
		char ht[30];
		NS ns;
		char cmt[10];
		char k[50];
	public:
		friend istream& operator>>(istream &is, KH &a);
		friend ostream& operator<<(ostream &os, KH a);
		void agesort(KH k[], int n);
		char *getk() {
			return k;
		}
};
istream& operator>>(istream &is, KH &a) {
	cout << "nhap ho ten: "; is >> a.ht;
	cout << "nhap ngay, thang, nam sinh: "; is >> a.ns.dd >> a.ns.mm >> a.ns.yyyy;
	cout << "nhap so chung minh thu: "; is >> a.cmt;
	cout << "nhap ho khau: " ; is >> a.k;
}
ostream& operator<<(ostream &os, KH a) {
	os << "Ho ten: " << a.ht << endl;
	os << "Ngay sinh: " << a.ns.dd << "/" << a.ns.mm << "/" << a.ns.yyyy << endl;
	os << "So chung minh thu: " << a.cmt << endl;
	os << "Ho khau: " << a.k << endl; 
}
void KH::agesort(KH k[], int n) {
	for(int i = 0; i < n; i++) {
		for(int j = n - 1; j > i; j--) {
			if(k[j].ns.yyyy < k[j-1].ns.yyyy) {
				KH t = k[j];
				k[j] = k[j - 1];
				k[j - 1] = t;
			}
		}
	}
} 
int main() {
	KH k[50];
	int n;
	cout << "Nhap so khach hang: "; cin >> n;
	for(int i = 0; i < n; i++) {
		cout << "-So thu tu: " << i + 1 << endl;
		cin >> k[i];
	}
	cout << "Danh sach khach hang co ho khau o Ha Noi la: " << endl;
	for(int i = 0; i < n; i++) {
		if(strcmpi(k[i].getk(),"hanoi") == 0 ){
		cout << "STT: " << i + 1 << endl;
		cout << k[i];
	}
	}
	cout << "Danh sach khach hang sau khi sap xep la: " << endl;
	for(int i = 0; i < n; i++) {
		cout << "-STT: " << i + 1 << endl;
		k[i].agesort(k, n);
		cout << k[i];
	}
	return 0;
}
