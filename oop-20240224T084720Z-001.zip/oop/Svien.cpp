#include<iostream>
using namespace std;
class SV {
	private:
		string hoten;
		int day;
		int month;
		int year;
		string gender;
		float toan;
		float ly;
		float hoa;
	public:
		void nhap() {
			cout << "Nhap ho ten: "; cin >> hoten;
			cout << "Nhap ngay sinh: "; cin >> day;
			cout << "Nhap thang sinh: "; cin >> month;
			cout << "Nhap nam sinh: "; cin >> year;
			cout << "Nhap gioi tinh: "; cin >> gender;
			cout << "Nhap diem toan: "; cin >> toan;
			cout << "Nhap diem ly: "; cin >> ly;
			cout << "Nhap diem hoa: "; cin >> hoa;
		}
		
		float dtb() {
			return (toan + ly + hoa) / 3;
		}
		
};

int main() {
	SV sv1;
	sv1.nhap();
	cout<<sv1.dtb();
	return 0;
}
