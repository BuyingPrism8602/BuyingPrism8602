#include<iostream>
using namespace std;
class VecTor3 {
	private:
		int a, b, c;
	public:
		VecTor3(int a = 0, int b = 0, int c = 0) {
			this->a = a;
			this->b = b;
			this->c = c;
		}
		~VecTor3() {
		}
		void in() {
			cout << "("<<a<<", " << b <<", "<< c <<")" << endl ;
		}
		VecTor3 operator+(VecTor3 v) {
			VecTor3 kq;
			kq.a = this->a + v.a;
			kq.b = this->b + v.b;
			kq.c = this->c + v.c;
			return kq;
		}
		VecTor3 operator-(VecTor3 v) {
			VecTor3 kq;
			kq.a = this->a - v.a;
			kq.b = this->b - v.b;
			kq.c = this->c - v.c;
			return kq;
		}
};
int main() {
	int a1, b1, c1, a2, b2, c2;
	cout << "Nhap toa do vector thu nhat: "; cin >> a1 >> b1 >> c1;
	cout << "Nhap toa do vector thu hai: "; cin >> a2 >> b2 >> c2;
	VecTor3 v1(a1, b1, c1) , v2(a2, b2, c2), v3;
	cout << "Tong hai vector la: ";
	v3 = v1 + v2;
	v3.in();
	cout << "Hieu hai vector la: ";
	v3 = v1 - v2;
	v3.in();
}
