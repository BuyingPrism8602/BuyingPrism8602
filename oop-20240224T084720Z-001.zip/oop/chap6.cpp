#include<iostream>
#include<cstring>
using namespace std;
template<class T>
T max3(T a, T b, T c) {
	if(a > b && a > c) return a;
	else if(b > c) return b;
	else return c;
}
char *max3(char *s1, char *s2, char *s3) {
	if(strcmp(s1, s2) > 0 && strcmp(s1, s3) > 0) return s1;
	else if(strcmp(s2, s3) > 0) return s2;
	else return s3;
}
int main() {
	int a = 3, b = 5, c = 4;
	cout << "maxint = " << max3(a, b, c) << endl;
	float m = 1.1, n = 0.2, p = 0.3;
	cout << "maxfloat = " << max3(m, n, p) << endl;
	char *a1 = "a", *a2 = "c", *a3 = "b";
	cout << "maxchar = " << max3(*a1, *a2, *a3) << endl;
	return 0;
}
