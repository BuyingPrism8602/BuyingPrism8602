#include<iostream>
using namespace std;
template<class P>
P nhap(P a[], int n) {
	cout << "Nhap cac phan tu: "; 
	for(int i = 0; i < n; i++) {
		cin >> a[i];
	}
}
template<class P>
P xuat(P a[], int n) {
	for(int i = 0; i < n; i++) {
		cout << a[i] << " ";
	}
}
template<class P>
P sum(P a[], int n) {
	P S = a[0];
	for(int i = 1; i <= n; i++) {
		S += a[i];
	}
	cout << "Sum = " << S << endl;
}
class PS {
	int ts, ms;
	public:
		//dinh nghia toan tu nhap xuat
	friend istream& operator>>(istream &is, PS &a) {
		cout << "Nhap tu so: "; is >> a.ts;
		cout << "Nhap mau so: "; is >> a.ms;
	}
	friend ostream& operator<<(ostream &os, PS a) {
		os << a.ts << " / " << a.ms << endl;
	}	

};
int main() {
	// so nguyen
	int n;
	int a[100];
	cout << "Nhap so phan tu: "; cin >> n;
	nhap(a, n);
	xuat(a, n);
	cout << endl;
	sum(a, n);
}

