#include<iostream>
#include<cstring>
using namespace std;
class VDV {
	protected:
		char ten[25], dv[40];
		int sohc;
	public:
		VDV(){
		}
		VDV(char ten[25], char dv[25], int sohc) {
			strcpy(this->ten, ten);
			strcpy(this->dv, dv);
			this->sohc = sohc;
		}
		~VDV() {
		}
		void nhap(){
			fflush(stdin);
			cout << "Nhap ten vdv: "; cin.getline(ten, 25);
			cout << "Nhap so huy chuong: "; cin >> sohc;
			fflush(stdin);
			cout << "Nhap don vi thi dau: "; cin.getline(dv, 40);
		}
		void xuat(){
			cout << "Ten: " << ten << endl;
			cout << "So huy chuong: " << sohc << endl;
			cout << "Don vi thi dau: " << dv << endl;
		}
};
class VDVVO: public VDV{
	int hangcan;
	char ndtd[50];
	public:
		VDVVO(){
		}
		VDVVO(char ten[] , char dv[], int sohc, int hangcan, char ndtd[]):VDV(ten, dv, sohc) {
			this->hangcan = hangcan;
			strcpy(this->ndtd, ndtd);
		}
		friend istream& operator>>(istream &is, VDVVO &vo) {
			vo.nhap();
			cout << "Nhap so hang can: "; is >> vo.hangcan;
			fflush(stdin);
			cout << "Nhap noi dung thi dau: "; is.getline(vo.ndtd, 50);
		}
		friend ostream& operator<<(ostream &os, VDVVO vo) {
			vo.xuat();
			os << "Hang can: " << vo.hangcan << endl;
			os << "Noi dung thi dau: " << vo.ndtd << endl; 
			os << "Thuong: " << vo.thuong() << endl;
		}
		long thuong() {
			return sohc * 10000000;
		}
		char* getten() {
			return ten;
		}
		bool operator == (char *a) {
			if(strcmpi(getten(), a) == 0 == true)
			return getten() == a;
		}
		int getsohc() {
			return sohc;
		}
		int gethangcan() {
			return hangcan;
		}
};
int main() {
	VDVVO v[100];
	int n;
	cout << "Nhap so van dong vien: "; cin >> n;
	for(int i = 0; i < n; i++) {
		cout << "STT: " << i + 1 << endl;
		cin >> v[i];
	}
	cout << "VDV ten Anh " << endl;
	char a[25] = "Anh";
	for(int i = 0; i < n; i++) {
		if(v[i].getten() == a)
		cout << v[i];
	}
	int max = v[0].getsohc();
	for(int i = 0; i < n; i++) {
		if(v[i].getsohc() > max)
		max = v[i].getsohc();
	}
	cout << "**VDV vo thuat co so huy chuong lon nhat la: " << endl;
	for(int i = 0; i < n; i++) {
		if(v[i].getsohc() == max)
		cout << v[i];
	}
	cout << "**Danh sach vdv sau khi sap xep la: " << endl;
	for(int i = 0; i < n; i++) {
		for(int j = n - 1; j > i; j--) {
			if(v[j].gethangcan() > v[j - 1].gethangcan()) {
				VDVVO t = v[j];
				v[j] = v[j - 1];
				v[j - 1] = t;
			}
		}
		cout << v[i];
	}
	int k;
	cout << "-Nhap vi tri thu (k + 1) can xoa: "; cin >> k;
	n--;
	for(int i = k; i < n; i++) {
		v[i] = v[i + 1];
	}
	for(int i = 0; i < n; i++) {
		cout << v[i];
	}
	for(int i = n - 1; i >= k; i--) {
		v[i + 1] = v[i];
		if(i == k) {
			cout << "Nhap phan tu thu (k + 1) can them: "; cin >> v[i];
		}
	}
	n++;
	for(int i = 0; i < n; i++) {
		cout << v[i];
	}
	return 0;
}
