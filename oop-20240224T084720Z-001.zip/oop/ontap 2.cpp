#include<iostream>
#include<cstring>
using namespace std;
class NONGSAN {
	private:
		char mans[10];
		char tenns[30];
		long dongia;
	public:
		NONGSAN() {
			
		}
		NONGSAN(char mans[], char tenns[], long dongia){
			strcpy(this->mans, mans);
			strcpy(this->tenns, tenns);
			this->dongia = dongia;
		}
		~NONGSAN() {
			
		}
		void nhap() {
			cin.ignore();
			cout << "Nhap ma nong san: "; cin.getline(mans, 10);
			cout << "Nhap ten nong san: "; cin.getline(tenns, 30);
			cout << "Nhap don gia: "; cin >> dongia;
		}
		void in() {
			cout << "Ma nong san: " << mans << endl;
			cout << "Ten nong san: " << tenns << endl;
			cout << "Don gia: " << dongia << endl;
		}
		long getdongia() {
			return dongia;
		}
};
class NSMB: public NONGSAN {
	private:
		char dcng[40];
		int soluong;
	public:
		NSMB() {
			
		}
		NSMB(char mans[], char tenns[], long dongia, char dcng[], int soluong) : NONGSAN(mans, tenns, dongia) {
			strcpy(this->dcng, dcng);
			this->soluong = soluong;
		}
		~NSMB() {
			
		}
		friend istream& operator>>(istream &is, NSMB &a) {
			a.nhap();
			is.ignore();
			cout << "Nhap dia chi nguon goc: "; is.getline(a.dcng, 40);
			cout << "Nhap so luong: "; is >> a.soluong;
		}
		friend ostream& operator<<(ostream &os, NSMB a) {
			a.in();
			os << "Dia chi nguon goc: " << a.dcng << endl;
			os << "So luong: " << a.soluong << endl;
			os << "Thanh tien: " << a.thanhtien() << endl;
		}
		long thanhtien() {
			return getdongia() * soluong;
		}
		friend bool operator == (NSMB a, char *c) {
			if(strcmpi(a.dcng, c) == 0)
			return true;
		}
};
int main() {
	/*NONGSAN ns[100];
	int n;
	cout << "Nhap so nong san: "; cin >> n;
	for(int i = 0; i < n; i++) {
		cout << "-STT: " << i + 1 << endl;
		ns[i].nhap();
	}
	cout << "DANH SACH NONG SAN: " << endl;
	for(int i = 0; i < n; i++) {
		cout << "-STT: " << i + 1 << endl;
		ns[i].in();
	}*/
	NSMB no[100];
	int m;
	cout << "Nhap so nong san mien Bac: "; cin >> m;
	for(int i = 0; i < m; i++) {
		cout << "-STT: " << i + 1 << endl;
		cin >> no[i];
	}
	cout << "DANH SACH NONG SAN HA GIANG: " << endl;
	for(int i = 0; i < m; i++) {
		cout << "-STT: " << i + 1 << endl;
		if(no[i] == "Ha Giang")
		cout << no[i];
	}
	int k;
	cout << "Nhap vi tri (i + 1) can them: "; cin >> k;
	NSMB n1;
	cout << "Nhap du lieu: "; cin >> n1;
	for(int i = m; i >= k + 1; i--) {
		no[i] = no[i - 1];
	}
	no[k] = n1;
	m++;
	cout << "DANH SACH NONG SAN MIEN BAC: " << endl;
	for(int i = 0; i < m; i++) {
		cout << no[i];
	}
}
