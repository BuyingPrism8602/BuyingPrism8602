#include<iostream>
#include<string.h>
using namespace std;

class MAITHANG{
	private://de lay diem toi da
		char ma[30], th[30];
		float gg;
	public:
		MAITHANG(char* ma = " ", char* th = " ", float gg = 0)
		{
			strcpy(this->ma, ma);
			strcpy(this->th, th);
			this->gg = gg;
		}
		~MAITHANG()
		{
			
		}
		
		friend istream&operator>>(istream &in, MAITHANG &a)
		{
			cout <<"\nNhap vao Ma :";
			fflush(stdin);
			in.getline(a.ma, 30);
			cout <<"\nNhap vao Ten Hang :";
			in.getline(a.th, 30);
			cout <<"\nNhap vao Gia Goc :";
			in >>a.gg;
			
			return in; 
		}
		
		friend ostream&operator<<(ostream &out, MAITHANG a)
		{
			out <<"\nMa :"<<a.ma
			    <<"\nTen Hang :"<<a.th
			    <<"\nGia Goc :"<<a.gg;
			    
			return out;
		}
		
		const float getgg()
		{
			return this->gg;
		}
};

class DIEUHOA:public MAITHANG{
	private:
		int csll;
	public:
		DIEUHOA(char* ma = " ", char* th = " ", float gg = 0, int csll = 0):MAITHANG(ma, th, gg)
		{
			this->csll = csll;
		}
		~DIEUHOA()
		{
			
		}
		
		friend istream&operator>>(istream &in, DIEUHOA &a)
		{
			in >>(MAITHANG &)a;
			cout <<"\nNhap vao cong suat lam lanh :";
			in >>a.csll;
			
			return in;
		}
		
		friend ostream&operator<<(ostream &out, DIEUHOA a)
		{
			out <<(MAITHANG &)a;
			out <<"\nCong Suat Lam Lanh :"<<a.csll
			    <<"\nGia Ban :"<<a.GiaBan()<<endl;
			
			return out;
		}
		
		float GiaBan()
		{
			float dgb = 0;
			if(csll < 9000)
			{
				dgb = getgg()*1.1;
			}
			else if(csll >= 9000 && csll < 18000)
			{
				dgb = getgg()*1.2;
			}
			else
			{
				dgb = getgg()*1.3;
			}
			
			return dgb;
		}
		
		friend bool operator !=(DIEUHOA x, float y)
		{
			return x.csll != y;
		}
};

void nhap_ds_SP(MAITHANG a[], int &n)
{
	for(int i = 0; i < n; i++)
	{
		cin >>a[i];
	}
}

void xuat_ds_SP(MAITHANG a[], int n)
{
	for(int i = 0; i < n; i++)
	{
		cout <<a[i]<<endl;
	}
}

void nhap_ds_DH(DIEUHOA b[], int &m)
{
	for(int i = 0; i < m; i++)
	{
		cin >>b[i];
	}
}

void xuat_ds_DH(DIEUHOA b[], int m)
{
	for(int i = 0; i < m; i++)
	{
		cout <<b[i]<<endl;
	}
}

void ds_cs_k_2000(DIEUHOA b[], int &m)
{
	for(int i = 0; i < m; i++)
	{
		if(b[i] != 2000)
		{
			cout <<b[i]<<endl;
		}
	}
}

void chen_ds(DIEUHOA b[], int &m)
{
	int k;
	cout <<"\nNhap vao vi tri can chen :";
	cin >>k;
	DIEUHOA x;
	cout <<"\nNhap vao cac thong tin can chen :";
	cin >>x;
	for(int i = m; i >= k; i--)
	{
		b[i] = b[i-1];
	}
	b[k] = x;
	m++;
	
	xuat_ds_DH(b, m);
}

void xoa(DIEUHOA b[], int &m)
{
	int k;
	cout <<"\nNhap vao vi tri can xoa :";
	cin >>k;
	for(int i = k; i < m; i++)
	{
		b[i] = b[i+1];
	}
	m--;
	
	xuat_ds_DH(b, m);
}


int main()
{
	int n;
	cout <<"\nNhap vao danh sach San Pham :";
	cin >>n;
	MAITHANG a[n];
	nhap_ds_SP(a, n);
	cout <<"\t\tThong Tin Danh Sach San Pham :"<<endl;
	xuat_ds_SP(a, n);
	int m;
	cout <<"\nNhap vao danh sach m Dieu Hoa :"<<endl;
	cin >>m;
	DIEUHOA b[m];
	nhap_ds_DH(b, m);
	cout <<"\t\tThong Tin danh Sach Dieu Hoa :"<<endl;
	xuat_ds_DH(b, m);
	cout <<"\t\tDanh Sach Dieu Hoa co Cong Suat != 2000"<<endl;
	ds_cs_k_2000(b, m);
	cout <<"\t\tDanh Sach Dieu Hoa da duoc Chen :"<<endl;
	chen_ds(b, m);
	cout <<"\t\tDanh Sach Dieu Hoa Da duoc xoa di vi tri K :"<<endl;
	xoa(b, m);
	
	return 0;
}